# Markdown Study Material

This is the Markdown File for study purpose.

> This document is in Markdown and some elements of HTML is added to this file. Add this document in any Markdown rendering tool to view the output.

## About Markdown

Markdown is a lightweight markup language that you can use to add formatting elements to plaintext text documents. Created by John Gruber in 2004, Markdown is now one of the world’s most popular markup languages. When you write in Markdown, the text is stored in a plaintext file that has an .md or .markdown extension.
Markdown applications use something called a Markdown processor (also commonly referred to as a “parser” or an “implementation”) to take the Markdown-formatted text and output it to HTML format. At that point, your document can be viewed in a web browser or combined with a style sheet and printed.

> The Markdown application and processor are two separate components.

### Markdown Process

A Markdown process workflow will look like:

![Markdown Process flow](image.png)

1. Create a Markdown file using a text editor or a dedicated Markdown application. The file should have an .md or .markdown extension.
2. Open the Markdown file in a Markdown application.
3. Use the Markdown application to convert the Markdown file to an HTML document.
4. View the HTML file in a web browser or use the Markdown application to convert it to another file format, like PDF.

### Basic Syntax

Below are some common Markdown Syntax to use:

#### Heading

To create a heading, add number signs (#) in front of a word or phrase. The number of number signs you use should correspond to the heading level.

> Example
>> In Markdown, it will look like 

# Heading level 1 
## Heading level 2 
### Heading level 3 
#### Heading level 4 
##### Heading level 5 
###### Heading level 6 

>> In HTML, it will look like 

<h1>Heading level 1</h1>
<h2>Heading level 2</h2>
<h3>Heading level 3</h3>
<h4>Heading level 4</h4>
<h5>Heading level 5</h5>
<h6>Heading level 6</h6>

#### Paragraphs

To create paragraphs, use a blank line to separate one or more lines of text. You should not indent paragraphs with spaces or tabs.

> Example
>> In Markdown, it will look like 

I really like using Markdown.

I think I'll use it from now on.

>> In HTML, it will look like 

<p>I really like using Markdown.</p>

<p>I think I'll use it from now on.</p>

#### Line Breaks

To create a line break (<br>), end a line with two or more spaces, and then type return.

> Example
>> In Markdown, it will look like 

I really like using Markdown.

I think I'll use it from now on.

>> In HTML, it will look like 

<p>This is the first line.<br />And this is the second line.</p>

#### Emphasis

You can add emphasis by making text bold or italic.

##### Bold

To bold text, add two asterisks or underscores before and after a word or phrase. To bold the middle of a word for emphasis, add two asterisks without spaces around the letters.

> Example
>> In Markdown, it will look like 

I love **bold text**.

I love __bold text__.

>> In HTML, it will look like 

I love <strong>bold text</strong>.

##### Italic

To italicize text, add one asterisk or underscore before and after a word or phrase. To italicize the middle of a word for emphasis, add one asterisk without spaces around the letters.

> Example
>> In Markdown, it will look like 

The *cat's meow*.

The _cat's meow_.

>> In HTML, it will look like 

The <em>cat's meow</em>.

##### Bold and Italic

To emphasize text with bold and italics at the same time, add three asterisks or underscores before and after a word or phrase.

> Example
>> In Markdown, it will look like 

***Important*** text.

___Important___ text.

__*Important*__ text.

**_Important_** text.

>> In HTML, it will look like 

<strong><em>Important</em></strong> text.

#### Blockquotes

To create a blockquote, add a > in front of a paragraph.

> Example
>> In Markdown, it will look like 

> Dorothy followed her through many rooms.

>> In HTML, it will look like 

<blockquote>
    <p>Dorothy followed her through many rooms.</p>
</blockquote>

##### Blockquotes with Multiple Paragraphs

Blockquotes can contain multiple paragraphs. Add a > on the blank lines between the paragraphs.

> Example
>> In Markdown, it will look like 

> This the first paragraph.
>
> And this is the second paragraph.

>> In HTML, it will look like 

<blockquote>
    <p>This the first paragraph.</p>
    <p>And this is the second paragraph.</p>
</blockquote>

##### Nested Blockquotes

Blockquotes can be nested. Add a >> in front of the paragraph you want to nest.

> Example
>> In Markdown, it will look like 

> This the first paragraph.
>
>> And this is the second paragraph.

>> In HTML, it will look like 

<blockquote>
    <p>This the first paragraph.</p>
    <blockquote>
        <p>And this is the nested paragraph.</p>
    </blockquote>
</blockquote>

##### Blockquotes with Other Elements

Blockquotes can contain other Markdown formatted elements. Not all elements can be used — you’ll need to experiment to see which ones work.

> Example
>> In Markdown, it will look like 

> ##### The quarterly results look great!
>
> - Revenue was off the chart.
> - Profits were higher than ever.
>
> *Everything* is going **well**.

>> In HTML, it will look like 

<blockquote>
    <h5>The quarterly results look great!</h5>
    <ul>
        <li>Revenue was off the chart.</li>
        <li>Profits were higher than ever.</li>
    </ul>
    <p><em>Everything</em> is going <strong>well</strong>.</p>
</blockquote>

#### List

List are of Ordered and Unordered types.

##### Ordered List

To create an ordered list, add line items with numbers followed by periods. The numbers don’t have to be in numerical order, but the list should start with the number one.

> Example
>> In Markdown, it will look like 

1. First item
2. Second item
3. Third item
4. Fourth item

>> In HTML, it will look like 

<ol>
    <li>First item</li>
    <li>Second item</li>
    <li>Third item</li>
    <li>Fourth item</li>

###### Nesting List Items

To nest line items in an ordered list, indent the items four spaces or one tab.

> Example
>> In Markdown, it will look like 

1. First item
2. Second item
3. Third item
    1. Indented item
    2. Indented item
4. Fourth item

>> In HTML, it will look like 

<ol>
    <li>First item</li>
    <li>Second item</li>
    <li>Third item
        <ol>
            <li>Indented item</li>
            <li>Indented item</li>
        </ol>
    </li>
    <li>Fourth item</li>
</ol>

##### Unordered List

To create an unordered list, add dashes (-), asterisks (*), or plus signs (+) in front of line items.

> Example
>> In Markdown, it will look like 

- First item
- Second item
- Third item
- Fourth item

>> In HTML, it will look like 

<ul>
    <li>First item</li>
    <li>Second item</li>
    <li>Third item</li>
    <li>Fourth item </li>
</ul>

###### Nesting List Items

To nest line items in an unordered list, indent the items four spaces or one tab.

> Example
>> In Markdown, it will look like 

- First item
- Second item
- Third item
    - Indented item
    - Indented item
- Fourth item

>> In HTML, it will look like 

<ul>
    <li>First item</li>
    <li>Second item</li>
    <li>Third item
        <ul>
            <li>Indented item</li>
            <li>Indented item</li>
        </ul>
    </li>
    <li>Fourth item</li>
</ul>

##### Adding Elements in Lists

To add another element in a list while preserving the continuity of the list, indent the element four spaces or one tab.

###### Paragraphs

> Example
>> In Markdown, it will look like 

* This is the first list item.
* Here's the second list item.

  I need to add another paragraph below the second list item.

* And here's the third list item.

>> In HTML, it will look like 

<ul>
    <li><p>This is the first list item.</p></li>
    <li><p>Here's the second list item.</p>
        <p>I need to add another paragraph below the second list item.</p>
    </li>
    <li><p>And here's the third list item.</p></li>
</ul>

###### Blockquotes

> Example
>> In Markdown, it will look like 

* This is the first list item.
* Here's the second list item.

  > A blockquote would look great here.

* And here's the third list item.

>> In HTML, it will look like 

<ul>
    <li><p>This is the first list item.</p></li>
    <li><p>Here's the second list item.</p>
        <blockquote>
        <p>A blockquote would look great here.</p>
        </blockquote>
    </li>
    <li><p>And here's the third list item.</p>
    </li>
</ul>

###### Code Blocks

Code blocks are normally indented four spaces or one tab. When they’re in a list, indent them eight spaces or two tabs.

> Example
>> In Markdown, it will look like 

1. Open the file.
2. Find the following code block on line 21:

  <html>
    <head>
      <title>Test</title>
    </head>

3. Update the title to match the name of your website.

>> In HTML, it will look like 

<ol>
    <li><p>Open the file.</p></li>
    <li><p>Find the following code block on line 21:</p>
        <pre><code>&lt;html&gt;
            &lt;head&gt;
                &lt;title&gt;Test&lt;/title&gt;
            &lt;/head&gt;
        </code></pre>
    </li>
    <li><p>Update the title to match the name of your website.</p></li>
</ol>

###### Images

> Example
>> In Markdown, it will look like 

1. Open the file containing Tux, the Linux mascot.
2. Marvel at its beauty.

    ![Tux](images/tux.png)

3. Close the file.

>> In HTML, it will look like 

<ol>
    <li><p>Open the file containing Tux, the Linux mascot.</p></li>
    <li>
        <p>Marvel at its beauty.</p>
        <p><img src="images/tux.png" alt="Tux" /></p>
    </li>
    <li><p>Close the file.</p></li>
</ol>

#### Code

To denote a word or phrase as code, enclose it in tick marks (`).

> Example
>> In Markdown, it will look like 

At the command prompt, type `nano`.

>> In HTML, it will look like 

At the command prompt, type <code>nano</code>.

##### Escaping Tick Marks

If the word or phrase you want to denote as code includes one or more tick marks, you can escape it by enclosing the word or phrase in double tick marks ( “).

> Example
>> In Markdown, it will look like 

``Use `code` in your Markdown file.``

>> In HTML, it will look like 

<code>Use `code` in your Markdown file.</code>

##### Code Blocks

To create code blocks, indent every line of the block by at least four spaces or one tab.

> Example
>> In Markdown, it will look like 

<html>
    <head>
    </head>
</html>

>> In HTML, it will look like 

<pre>
    <code>
        &lt;html&gt;
            &lt;head&gt;
            &lt;/head&gt;
        &lt;/html&gt;
    </code>
</pre>


#### Horizontal Rules

To create a horizontal rule, use three or more asterisks (***), dashes (---), or underscores (___) on a line by themselves.

> Example
>> In Markdown, it will look like 

******

>> In HTML, it will look like 

<hr />

#### Links

To create a link, enclose the link text in brackets (e.g., [Duck Duck Go]) and then follow it immediately with the URL in parentheses (e.g., (https://duckduckgo.com)).

> Example
>> In Markdown, it will look like 

Use [Duck Duck Go](https://duckduckgo.com).

>> In HTML, it will look like 

<p>Use <a href="https://duckduckgo.com">Duck Duck Go</a>.</p>

##### Adding Titles

You can optionally add a title for a link. This will appear as a tooltip when the user hovers over the link. To add a title, enclose it in parentheses after the URL.

> Example
>> In Markdown, it will look like 

Use [Duck Duck Go](https://duckduckgo.com "My search engine!").

>> In HTML, it will look like 

<p>Use <a href="https://duckduckgo.com" title="My search engine!">Duck Duck Go</a>.</p>>

##### URLs and Email Addresses

To quickly turn a URL or email address into a link, enclose it in angle brackets.

> Example
>> In Markdown, it will look like 

<https://eff.org>

>> In HTML, it will look like 

<a href="https://eff.org">https://eff.org</a>

##### Formatting Links

To emphasize links, add asterisks before and after the brackets and parentheses.

To quickly turn a URL or email address into a link, enclose it in angle brackets.

> Example
>> In Markdown, it will look like 

This is the *[EFF](https://eff.org)*.

>> In HTML, it will look like 

This is the <em><a href="https://eff.org">EFF</a></em>.</p>

##### Reference-style Links

Reference-style links are a special kind of link that make URLs easier to display and  read in Markdown. Reference-style links are constructed in two parts: the part you keep inline with your text and the part you store somewhere else in the file to keep the text easy to read.

###### Formatting the First Part of the Link

The first part of a reference-style link is formatted with two sets of brackets. The first set of brackets surrounds the text that should appear linked. The second set of brackets displays a label used to point to the link you’re storing elsewhere in your document.

> Example
>> In Markdown, it will look like 

[hobbit-hole][1]

###### Formatting the Second Part of the Link

The second part of a reference-style link is formatted with the following attributes:
1. The label, in brackets, followed immediately by a colon and at least one space (e.g., [label]: ).
2. The URL for the link, which you can optionally enclose in angle brackets.
3. The optional title for the link, which you can enclose in double quotes, single quotes, or parentheses.

> Example
>> In Markdown, it will look like 

[hobbit-hole]: https://en.wikipedia.org/wiki/Hobbit#Lifestyle

###### An Example Putting the Parts Together

> Example
>> In Markdown, it will look like 

In a hole in the ground there lived a hobbit. Not a nasty, dirty, wet hole, filled with the ends of worms and an oozy smell, nor yet a dry, bare, sandy hole with nothing in it to sit down on or to eat: it was a [hobbit-hole](https://en.wikipedia.org/wiki/Hobbit#Lifestyle "Hobbit life styles"), and that means comfort.

>> In HTML, it will look like 

<a href="https://en.wikipedia.org/wiki/Hobbit#Lifestyle" title="Hobbit lifestyles">hobbit-hole</a>

#### Images

To add an image, add an exclamation mark (!), followed by alt text in brackets, and the path or URL to the image asset in parentheses. You can optionally add a title after the URL in the parenthese.

> Example
>> In Markdown, it will look like 

![Philadelphia's Magic Gardens. This place was so cool!](images/philly-2 magic-garden.png "Philadelphia's Magic Gardens")

>> In HTML, it will look like 

<img src="images/philly-magic-garden.png" alt="Philadelphia's Magic Gardens. This place was so cool!" title="Philadelphia's Magic Gardens" />

#### Escaping Characters

To display a literal character that would otherwise be used to format text in a Markdown document, add a backslash (\) in front of the character.

> Example
>> In Markdown, it will look like 

\* Without the backslash, this would be a bullet in an unordered list.

>> In HTML, it will look like 

<p>* Without the backslash, this would be a bullet in an unordered list\
.</p>

##### Characters You Can Escape

Use a backslash to escape the following characters:

\ backslash
` tick mark (see also escaping tick marks in code)
* asterisk
_ underscore
{} curly braces
[] brackets
() parentheses
# pound sign
+ plus sign
- minus sign (hyphen)
. dot
! exclamation mark
| pipe (see also escaping pipe in tables)


### Extended Syntax

Several individuals and organizations took it upon themselves to extend the basic syntax by adding additional elements like tables, code blocks, syntax highlighting, URL auto-linking, and footnotes. These elements can be enabled by using a lightweight markup language that builds upon the basic Markdown syntax, or by adding an extension to a compatible Markdown processor.

#### Availability

Extended syntax isn’t available in all Markdown applications. You’ll need to check whether or not the lightweight markup language your application is using supports extended syntax. If it doesn’t, it may still be possible to enable extensions in your Markdown processor.

##### Markdown Processors

This are the [Markdown Processors List](https://github.com/markdown/markdown.github.com/wiki/Implementations) that can be used.

#### Tables

To add a table, use three or more hyphens (---) to create each column’s header, and use pipes (|) to separate each column. You can optionally add pipes on either end of the table.

> Example
>> In Markdown, it will look like 

| Syntax | Description |
| ----------- | ----------- |
| Header | Title |
| Paragraph | Text |

>> In HTML, it will look like 

<table>
    <thead>
        <tr class="header">
            <th>Syntax</th>
            <th>Description</th>
        </tr>
    </thead>
    <tbody>
        <tr class="odd">
            <td>Header</td>
            <td>Title</td>
        </tr>
        <tr class="even">
            <td>Paragraph</td>
            <td>Text</td>
        </tr>
    </tbody>
</table>

##### Alignment

Align text in the columns to the left, right, or center by adding a colon (:) to the left, right, or on both side of the hyphens within the header row.

> Example
>> In Markdown, it will look like 

| Syntax | Description | Test Text |
| :--- | :----: | ---: |
| Header | Title | Here's this |
| Paragraph | Text | And more |

>> In HTML, it will look like 

<table>
    <thead>
        <tr class="header">
            <th style="text-align: left;">Syntax</th>
            <th style="text-align: center;">Description</th>
            <th style="text-align: right;">Test Text</th>
        </tr>
    </thead>
    <tbody>
        <tr class="odd">
            <td style="text-align: left;">Header</td>
            <td style="text-align: center;">Title</td>
            <td style="text-align: right;">Here’s this</td>
        </tr>
        <tr class="even">
            <td style="text-align: left;">Paragraph</td>
            <td style="text-align: center;">Text</td>
            <td style="text-align: right;">And more</td>
        </tr>
    </tbody>
</table>

##### Formatting Text in Tables

You can format the text within tables. For example, you can add links, code (words or phrases in tick marks (`) only, not code blocks), and emphasis. You can’t add headings, blockquotes, lists, horizontal rules, images, or HTML tags.

##### Escaping Pipe Characters in Tables

You can display a pipe (|) character in a table by using its HTML character code (&#124;).

#### Fenced Code Blocks

The basic Markdown syntax allows you to create code blocks by indenting lines by four spaces or one tab. If you find that inconvenient, try using fenced code blocks. Depending on your Markdown processor or editor, you’ll use three tick marks (```) or three tildes (∼∼∼) on the lines before and after the code block.

> Example
>> In Markdown, it will look like 

```
    {
        "firstName": "John",
        "lastName": "Smith",
        "age": 25
    }
```

>> In HTML, it will look like 

<pre>
    <code>
        {
            &quot;firstName&quot;: &quot;John&quot;,
            &quot;lastName&quot;: &quot;Smith&quot;,
            &quot;age&quot;: 25
        }
    </code>
</pre>

##### Syntax Highlighting

Many Markdown processors support syntax highlighting for fenced code blocks. This feature allows you to add color highlighting for whatever language your code was written in. To add syntax highlighting, specify a language next to the tick marks before the fenced code block.

> Example
>> In Markdown, it will look like 

```json
{
    "firstName": "John",
    "lastName": "Smith",
    "age": 25
}
```

>> In HTML, it will look like 

<pre>
    <code class="language-json">
        {
            &quot;firstName&quot;: &quot;John&quot;,
            &quot;lastName&quot;: &quot;Smith&quot;,
            &quot;age&quot;: 25
        }
    </code>
</pre>

#### Footnotes

Footnotes allow you to add notes and references without cluttering the body of the document. When you create a footnote, a superscript number with a link appears where you added the footnote reference. Readers can click the link to jump to the content of the footnote at the bottom of the page.

To create a footnote reference, add a caret and an identifier inside brackets ([^1]). Identifiers can be numbers or words, but they can’t contain spaces or tabs. Identifiers only correlate the footnote reference with the footnote itself — in the output,
footnotes are numbered sequentially.

Add the footnote using another caret and number inside brackets with a colon and text ([^1]: My footnote.). You don’t have to put footnotes at the end of the document. You can put them anywhere except inside other elements like lists, block quotes, and tables.

> Example
>> In Markdown, it will look like 

Here's a simple footnote,[^1] and here's a longer one.[^bignote]

[^1]: This is the first footnote.

[^bignote]: Here's one with multiple paragraphs and code.

    Indent paragraphs to include them in the footnote.

    `{ my code }`

    Add as many paragraphs as you like.

>> In HTML, it will look like 

<p>
    Here’s a simple footnote,<a href="#fn1" class="footnote-ref" id="fnre\
f1"><sup>1</sup></a> and here’s a longer one.<a href="#fn2" class="foot\
note-ref" id="fnref2"><sup>2</sup></a>
</p>
<section class="footnotes">
    <hr />
    <ol>
        <li id="fn1"><p>This is the first footnote.<a href="#fnref1" class=\
    "footnote-back">&#8617;&#xFE0E;</a></p></li>
        <li id="fn2">
            <p>Here’s one with multiple paragraphs and code.</p>
            <p>Indent paragraphs to include them in the footnote.</p>
            <p><code>{ my code }</code></p>
            <p>Add as many paragraphs as you like.<a href="#fnref2" class="footnote-back">&#8617;&#xFE0E;</a></p>
        </li>
    </ol>
</section>

#### Heading IDs

Adding custom IDs allows you to link directly to headings and modify them with CSS. To add a custom heading ID, enclose the custom ID in curly braces on the same line as the heading.

> Example
>> In Markdown, it will look like 

### My Great Heading {#custom-id}

>> In HTML, it will look like 

<h3 id="custom-id">My Great Heading</h3>

##### Linking to heading IDs

You can link to headings with custom IDs in the file by creating a standard link with a number sign (#) followed by the custom heading ID.

> Example
>> In Markdown, it will look like 

[Heading IDs](#heading-ids)

>> In HTML, it will look like 

<a href="#heading-ids">Heading IDs</a>

#### Definition Lists

To create a definition list, type the term on the first line. On the next line, type a colon followed by a space and the definition.

> Example
>> In Markdown, it will look like 

First Term
: This is the definition of the first term.

Second Term
: This is one definition of the second term.
: This is another definition of the second term.

>> In HTML, it will look like 

<dl>
    <dt>First Term</dt>
    <dd>This is the definition of the first term.</dd>
    <dt>Second Term</dt>
    <dd>This is one definition of the second term. </dd>
    <dd>This is another definition of the second term.</dd>
</dl>

#### Strikethrough

You can “strikethrough” words by putting a horizontal line through the center of them. This feature allows you to indicate that certain words are a mistake not meant for inclusion in the document. To strikethrough words, use two tilde symbols (∼∼) before and after the words.

> Example
>> In Markdown, it will look like 

The world is ~~flat~~ round.

>> In HTML, it will look like 

<p>The world is <del>flat</del> round.</p>

#### Task Lists

Task lists allow you to create a list of items with checkboxes. In Markdown applications that support task lists, checkboxes will be displayed next to the content. To create a task list, add dashes (-) and brackets with a space ([ ]) in front of task list items. To select a checkbox, add an x in between the brackets ([x]).

> Example
>> In Markdown, it will look like 

- [x] Write the press release
- [ ] Update the website

#### Automatic URL Linking

Many Markdown processors automatically turn URLs into links. That means if you type http://www.example.com, your Markdown processor will automatically turn it into a link even though you haven’t used brackets.

##### Disabling Automatic URL Linking

If you don’t want a URL to be automatically linked, you can remove the link by denoting the URL as code with tick marks.


### Markdown Cheat Sheet

#### Elements

##### Block Quote

> This is a quote
>
>> Nested quote

##### Ordered List

1. First
2. Second
    1. Numbers
    2. Don’t matter

##### Unordered List

* Asterisks
* List
    * Nested

##### Images 

![Alt](https://a.com)

![Relative](/img.jpg)

##### Checklist

- [ ] Must include space

- [x] Completed

##### Tables

| Name | Age |
| ----- | --- |
| Kyle | 28 |
| Sally | 45 |

| Right | Center | Left |
| ----: | :----: | :--- |
| Kyle | 28 | Hi |
| Sally | 45 | Bye |

#### Basic Text Elements

##### Headings

Ids only allowed in extended markdown

# Head 1

## Head 2

### Head 3 {#my-id}

#### Head 4

##### Head 5

###### Head 6

##### Paragraphs

Will be same

paragraph

if only one new line used


New paragraph if two or 
more new lines are used

##### Line Breaks

Two spaces  
at end of line will make a line break

##### Links

Automatic linking (last example) only allowed in extended markdown.

[Label](https://url.com)

[Relative](/other-page)

[Id](#my-id)

<https://url.com>

https://extended.com

##### Horizontal Rule

Needs new lines between
---
Can use asterisks or underscores
***
Must use at least 3 but can use more
________

#### Text Styling

##### Bold

This is **bold**

This is __also bold__

Use as**teris**ks for mid word bolding

##### Italics

This is *italic*

This is _also italic_

Use as*teris*ks for mid word italics

##### Italics/Bold

This is ***both***

This is ___also both___

Any combo for __*both*__

Use as***teris***ks for mid word emphasis

##### Strikethrough

This is ~~crossed out~~

##### Highlight

This is ==highlighted==

##### Subscript

H~2~0 

##### Superscript

x^2^

##### Emoji

I am happy :smile:

#### Code

##### Inline Code

JS Variable: `let x = 1`

###### Code Block

Technically this is only supported with extended markdown but it should work everywhere. Labeling the language (js in our case) is not as widely supported, but will give syntax highlighting where supported.

```js

const x = 3

let y = 4

```






